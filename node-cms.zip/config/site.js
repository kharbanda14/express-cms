module.exports.config = {
    site_name:'Express CMS',
    site_url:'http://localhost:3000/',
    base_url:'http://localhost:3000/',
    meta:{
        title:'Express CMS',
        description:'CMS Built On Express.js'
    }

}